﻿using System;
using System.Threading;

namespace WindowsFormsApplication
{
    // Special class that is an argument to the ThreadPool method.
    class ThreadInfo1
    {
        public string FileName { get; set; }
        public int SelectedIndex { get; set; }
    }

    public class Class1
    {
        static readonly object _threadlock = new Object();
        public Class1()
        {
        }

        public void test()
        {
            // Declare a new argument object.
            ThreadInfo1 threadInfo = new ThreadInfo1();

            // Send the custom object to the threaded method.
            ThreadPool.SetMaxThreads(1, 1);
            for (int i = 0; i < 20; i++)
            {
                threadInfo.FileName = "THREAD - " + i;
                ThreadPool.QueueUserWorkItem(new WaitCallback(PrintOut), threadInfo);
                Thread.Sleep(50);
            }

            //Console.WriteLine(count);
        }

        public static int count = 0;
        static void PrintOut(object parameter)
        {
            lock (Class1._threadlock)
            {
                ThreadInfo1 threadInfo = parameter as ThreadInfo1;
                Console.WriteLine(threadInfo.FileName);
                Console.WriteLine(DateTime.Now);
                Console.WriteLine();
                Console.WriteLine();
                count++;
            }
        }
    }
}
