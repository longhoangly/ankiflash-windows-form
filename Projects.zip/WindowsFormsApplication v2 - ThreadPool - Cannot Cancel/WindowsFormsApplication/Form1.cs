﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using WindowsFormsApplication.Properties;
using Mono.Web;

namespace WindowsFormsApplication
{
    delegate void SetTextCallback(string text);
    delegate void SetUiCallback();

    public partial class MainForm : Form
    {
        readonly object _threadlock = new object();
        private string _ankiCard;
        private string _language;
        private string _proxy;
        private string[] _words;
        private string _successResult;
        private string _failureResult;
        private int _count;

        FlashcardsGenerator flashcardsGenerator = new FlashcardsGenerator();

        public MainForm()
        {
            InitializeComponent();
            EmbededCopy();
            //CopyFactory(@"..\..\Resources", @".\images");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Location = new Point(300, 100);
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            txtInputPath.Text = "";
            txtInput.Text = "";

            openFileDialog.CheckFileExists = true;
            openFileDialog.RestoreDirectory = true;

            openFileDialog.InitialDirectory = @"C:\";
            openFileDialog.Title = "Browse Text Files";

            openFileDialog.DefaultExt = "txt";
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                foreach (string file in openFileDialog.FileNames)
                {
                    try
                    {
                        txtInputPath.Text += file + "; ";
                        txtInput.Text += File.ReadAllText(file);
                    }
                    catch (IOException ex)
                    {
                        Console.WriteLine(ex.ToString());
                        throw;
                    }
                }
            }
        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {
            _words = txtInput.Text.Split('\n').Where(w => !string.IsNullOrEmpty(w) && !w.Equals("\r")).ToArray();
            txtNumInput.Text = _words.Count().ToString();

            if (_words.Any())
            {
                btnRun.Enabled = true;
                labelLanguages.Enabled = true;
                comBoxLanguages.Enabled = true;
            }
            else
            {
                btnRun.Enabled = false;
                labelLanguages.Enabled = false;
                comBoxLanguages.Enabled = false;
            }

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            btnCancel.Enabled = true;
            btnRun.Enabled = false;
            comBoxLanguages.Enabled = false;
            chkBoxUseProxy.Enabled = false;
            labelProxyConnection.Enabled = false;
            txtProxyString.Enabled = false;
            btnSave.Enabled = false;
            txtOutputPath.Enabled = false;

            _language = comBoxLanguages.Text;
            _proxy = chkBoxUseProxy.Checked ? txtProxyString.Text : "";

            proBar.Maximum = _words.Length;
            txtOutput.Text = "";
            _successResult = "";
            _failureResult = "";

            ThreadPool.SetMaxThreads(20, 20);
            ThreadInfo threadInfo = new ThreadInfo();
            for (int i = 0; i < _words.Length; i++)
            {
                threadInfo.word = _words[i];
                threadInfo.id = i;
                ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadProcSafe), threadInfo);
                Thread.Sleep(50);
            }
        }

        private void ThreadProcSafe(object info)
        {
            lock (_threadlock)
            {
                ThreadInfo threadInfo = info as ThreadInfo;
                _ankiCard = flashcardsGenerator.GenerateFlashCards(threadInfo.word.Replace("\r", "").Replace("\n", ""), _proxy, _language);
                _count++;
                if (_ankiCard.Contains("No flashcard for the word"))
                {
                    _ankiCard = _ankiCard.Replace("No flashcard for the word:", (threadInfo.id + 1).ToString() + " - ");
                    _failureResult += _ankiCard;
                }
                else
                {
                    _successResult += _ankiCard;
                    this.SetOutputText(_ankiCard);
                }

                if (_count == _words.Length)
                {
                    if (!string.IsNullOrEmpty(_failureResult))
                    {
                        MessageBox.Show("Cannot generate flashcard for following words: \n" + _failureResult,
                        "Failure Results");
                    }
                    this.SetUIElements();
                    this.btnSave.Enabled = true;
                    this.txtOutputPath.Enabled = true;
                }
            }
        }

        private void SetOutputText(string text)
        {
            if (text.Length > 100)
                text = text.Substring(0, 100) + "\r\n";

            if (this.txtOutput.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetOutputText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.txtOutput.Text += text;
            }
        }

        private void SetUIElements()
        {
            if (this.txtOutput.InvokeRequired)
            {
                SetUiCallback d = new SetUiCallback(SetUIElements);
                this.Invoke(d, new object[] { });
            }
            else
            {
                this.btnCancel.Enabled = false;
                this.btnRun.Enabled = true;
                this.comBoxLanguages.Enabled = true;
                this.chkBoxUseProxy.Enabled = true;
                this.labelProxyConnection.Enabled = chkBoxUseProxy.Checked;
                this.txtProxyString.Enabled = chkBoxUseProxy.Checked;
            }
        }

        private void txtOutput_TextChanged(object sender, EventArgs e)
        {
            string[] outputs = txtOutput.Text.Split('\n').Where(w => !string.IsNullOrEmpty(w) && !w.Equals("\r")).ToArray();
            txtNumOutput.Text = outputs.Count().ToString();
            proBar.Value = outputs.Count();
        }

        private void chkBoxUseProxy_CheckedChanged(object sender, EventArgs e)
        {
            labelProxyConnection.Enabled = chkBoxUseProxy.Checked;
            txtProxyString.Enabled = chkBoxUseProxy.Checked;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetUIElements();
            btnSave.Enabled = false;
            txtOutputPath.Enabled = false;

            MessageBox.Show("Canceled.\n", "Info");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.CheckFileExists = false;

            saveFileDialog.InitialDirectory = @"C:\";
            saveFileDialog.Title = "Save File";

            saveFileDialog.DefaultExt = "txt";
            saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StreamWriter outputFile = new StreamWriter(saveFileDialog.FileName);
                _successResult = HttpUtility.HtmlDecode(_successResult);
                outputFile.WriteLine(_successResult);
            }

            txtOutputPath.Text = saveFileDialog.FileName;
        }

        private void EmbededCopy()
        {
            if (Directory.Exists(@".\images\card"))
                FlashcardsGenerator.ClearDirectory(@".\images\card");
            if (Directory.Exists(@".\images\oxlayout")) FlashcardsGenerator.ClearDirectory(@".\images\oxlayout");
            if (Directory.Exists(@".\images\soha")) FlashcardsGenerator.ClearDirectory(@".\images\soha");

            Directory.CreateDirectory(@".\images\card");
            Directory.CreateDirectory(@".\images\oxlayout");
            Directory.CreateDirectory(@".\images\soha");

            #region Card folder
            string input = Properties.Resources.NoteType;
            File.WriteAllText(@".\images\card\NoteType.txt", input);

            input = Properties.Resources.card;
            File.WriteAllText(@".\images\card\card.css", input);

            input = Properties.Resources.front;
            File.WriteAllText(@".\images\card\front.html", input);

            input = Properties.Resources.back;
            File.WriteAllText(@".\images\card\back.html", input);
            #endregion

            #region Oxlayout folder
            input = Properties.Resources._interface;
            File.WriteAllText(@".\images\oxlayout\interface.css", input);

            input = Properties.Resources.jquery;
            File.WriteAllText(@".\images\oxlayout\jquery.js", input);

            input = Properties.Resources.oxford;
            File.WriteAllText(@".\images\oxlayout\oxford.css", input);

            input = Properties.Resources.bootstrap_min;
            File.WriteAllText(@".\images\oxlayout\bootstrap.min.css", input);

            input = Properties.Resources.common;
            File.WriteAllText(@".\images\oxlayout\common.js", input);

            input = Properties.Resources.oxfordjs;
            File.WriteAllText(@".\images\oxlayout\oxford.js", input);

            input = Properties.Resources.responsive;
            File.WriteAllText(@".\images\oxlayout\responsive.css", input);

            Bitmap input2 = Properties.Resources.btn_wordlist;
            input2.Save(@".\images\oxlayout\btn-wordlist.png");

            input2 = Properties.Resources.usonly_audio;
            input2.Save(@".\images\oxlayout\usonly_audio.png");

            input2 = Properties.Resources.enlarge_img;
            input2.Save(@".\images\oxlayout\enlarge_img.png");

            input2 = Properties.Resources.entry_arrow;
            input2.Save(@".\images\oxlayout\entry_arrow.png");

            input2 = Properties.Resources.entry_bullet;
            input2.Save(@".\images\oxlayout\entry_bullet.png");

            input2 = Properties.Resources.entry_sqbullet;
            input2.Save(@".\images\oxlayout\entry_sqbullet.png");

            input2 = Properties.Resources.go_to_top;
            input2.Save(@".\images\oxlayout\go_to_top.png");

            input2 = Properties.Resources.icon_academic;
            input2.Save(@".\images\oxlayout\icon_academic.png");

            input2 = Properties.Resources.icon_audio_bre;
            input2.Save(@".\images\oxlayout\icon_audio_bre.png");

            input2 = Properties.Resources.icon_audio_name;
            input2.Save(@".\images\oxlayout\icon_audio_name.png");

            input2 = Properties.Resources.icon_ox3000;
            input2.Save(@".\images\oxlayout\icon_ox3000.png");

            input2 = Properties.Resources.icon_plus_minus;
            input2.Save(@".\images\oxlayout\icon_plus_minus.png");

            input2 = Properties.Resources.icon_plus_minus_grey;
            input2.Save(@".\images\oxlayout\icon_plus_minus_grey.png");

            input2 = Properties.Resources.icon_plus_minus_orange;
            input2.Save(@".\images\oxlayout\icon_plus_minus_orange.png");

            input2 = Properties.Resources.icon_select_arrow_circle_blue;
            input2.Save(@".\images\oxlayout\icon_select_arrow_circle_blue.png");

            input2 = Properties.Resources.login_bg;
            input2.Save(@".\images\oxlayout\login_bg.png");

            input2 = Properties.Resources.pvarr;
            input2.Save(@".\images\oxlayout\pvarr.png");

            input2 = Properties.Resources.pvarr_blue;
            input2.Save(@".\images\oxlayout\pvarr_blue.png");

            input2 = Properties.Resources.search_mag;
            input2.Save(@".\images\oxlayout\search_mag.png");
            #endregion

            #region Soha folder
            input = Properties.Resources.main_min;
            File.WriteAllText(@".\images\soha\main_min.css", input);

            input2 = Properties.Resources.dot;
            input2.Save(@".\images\soha\dot.jpg");

            input2 = Properties.Resources.minus_section;
            input2.Save(@".\images\soha\minus_section.jpg");

            input2 = Properties.Resources.plus_section;
            input2.Save(@".\images\soha\plus_section.jpg");

            input2 = Properties.Resources.hidden;
            input2.Save(@".\images\soha\hidden.jpg");

            input2 = Properties.Resources.external;
            input2.Save(@".\images\soha\external.png");
            #endregion
        }

        private void CopyFactory(string srcPath, string despath)
        {
            DirectoryInfo dir = new DirectoryInfo(srcPath);

            if (Directory.Exists(despath + @"\" + dir.Name))
                FlashcardsGenerator.ClearDirectory(despath + @"\" + dir.Name);

            foreach (FileInfo fi in dir.GetFiles())
            {
                fi.CopyTo(despath + @"\" + fi.Name);
            }

            foreach (DirectoryInfo di in dir.GetDirectories())
            {
                Directory.CreateDirectory(despath + @"\" + di.Name);
                CopyFactory(di.FullName, despath + @"\" + di.Name);
            }
        }
    }

    class ThreadInfo
    {
        public string word { get; set; }
        public int id { get; set; }
    }
}
