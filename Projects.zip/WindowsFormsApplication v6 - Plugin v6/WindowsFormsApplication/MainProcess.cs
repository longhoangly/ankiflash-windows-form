﻿using System;
using System.IO;
using System.Net;
using CsQuery;
using Mono.Web;

namespace WindowsFormsApplication
{
    internal class FlashcardsGenerator
    {
        private CQ _oxfDocument = "";
        private CQ _sohaDocument = "";

        private string _wrd = "";
        private string _wordType = "";
        private string _phonetic = "";
        private string _example = "";
        private string _proUk = "";
        private string _proUs = "";
        private string _oxfContent = "";
        private string _sohaContent = "";
        private string _thumb = "";
        private string _img = "";
        private string _ankiCard = "";
        private string _copyRight = "";
        private char _tag;

        private const string LangEng = "English";
        private const string LangViet = "Vietnamese";
        private const string LangEngViet = "English & Vietnamese";

        private const string SpelNotOk = "Spelling Failed";
        private const string GenOk = "OK";
        public const string ConNotOk = "Connection Failed";
        public const string GenNotOk = "Generating Failed";

        public string GenerateFlashCards(string word, string proxyStr, string language)
        {
            Console.WriteLine("Generate Card for Word: " + word);

            #region Get Input & Check Condition
            if (language.Equals(LangEng))
            {
                if (checkOxfordContent(word, proxyStr).Equals(GenOk))
                {
                    _oxfContent = GetOxfordContent(_oxfDocument);
                }
                else if (checkOxfordContent(word, proxyStr).Equals(ConNotOk))
                {
                    return ConNotOk;
                }
                else
                {
                    return GenNotOk + "-" + word + "\r\n";
                }
            }
            else
            {
                if (checkOxfordContent(word, proxyStr).Equals(GenOk) && checkSohaContent(word, proxyStr).Equals(GenOk))
                {
                    _oxfContent = GetOxfordContent(_oxfDocument);
                    _sohaContent = GetSohaContent(_sohaDocument);
                    _sohaContent = _sohaContent.Replace("<div id=\"firstHeading\"> </div>", "<div id=\"firstHeading\">" + word + "</div>");
                }
                else if (checkOxfordContent(word, proxyStr).Equals(ConNotOk) && checkSohaContent(word, proxyStr).Equals(ConNotOk))
                {
                    return ConNotOk;
                }
                else
                {
                    return GenNotOk + "-" + word + "\r\n";
                }
            }
            #endregion

            _wordType = "(" + GetElementText(_oxfDocument, "span[class=pos]", 0) + ")";
            _phonetic = GetPhonetic(_oxfDocument);
            _example = GetExamples(_oxfDocument, _wrd);
            _proUk = GetPronunciation(_oxfDocument, proxyStr, "div.pron-uk");
            _proUs = GetPronunciation(_oxfDocument, proxyStr, "div.pron-us");
            _thumb = GetImages(_oxfDocument, proxyStr, "img.thumb", "src");
            _img = GetImages(_oxfDocument, proxyStr, "a[class=topic]", "href");
            _tag = _wrd[0];
            _copyRight = "This flashcard's content is get from the Oxford Advanced Learner's & Soha Online Dictionaries.<br>Thanks Oxford & Soha Dictionaries! Thanks for using!";

            #region build string _ankiCard
            if (language.Equals(LangEng))
            {
                _copyRight = "This flashcard's content is get from the Oxford Advanced Learner's Dictionary.<br>Thanks Oxford Dictionary! Thanks for using!";
                _ankiCard = _wrd + "\t" + _wordType + "\t" + _phonetic + "\t" + _example + "\t" + _proUk + "\t" + _proUs + "\t" + _thumb + "\t" + _img + "\t" + _oxfContent + "\t" + _copyRight + "\t" + _tag + "\r\n";
            }
            else if (language.Equals(LangViet))
            {
                _ankiCard = _wrd + "\t" + _wordType + "\t" + _phonetic + "\t" + _example + "\t" + _proUk + "\t" + _proUs + "\t" + _thumb + "\t" + _img + "\t" + _sohaContent + "\t" + _copyRight + "\t" + _tag + "\r\n";
            }
            else if (language.Equals(LangEngViet))
            {
                _ankiCard = _wrd + "\t" + _wordType + "\t" + _phonetic + "\t" + _example + "\t" + _proUk + "\t" + _proUs + "\t" + _thumb + "\t" + _img + "\t" + _oxfContent + "\t" + _sohaContent + "\t" + _copyRight + "\t" + _tag + "\r\n";
            }
            else
            {
                _ankiCard = _wrd + "\t" + _wordType + "\t" + _phonetic + "\t" + _example + "\t" + _proUk + "\t" + _proUs + "\t" + _thumb + "\t" + _img + "\t" + _sohaContent + "\t" + _oxfContent + "\t" + _copyRight + "\t" + _tag + "\r\n";
            }
            #endregion

            return _ankiCard;
        }

        #region Functional Functions
        private string checkOxfordContent(string word, string proxyStr)
        {
            string url = "";
            if (word.Contains("www.oxfordlearnersdictionaries.com"))
            {
                url = word;
            }
            else
            {
                word = word.Replace(" ", "%20");
                url = "http://www.oxfordlearnersdictionaries.com/search/english/direct/?q=" + word;
            }

            StreamReader st = HttpGetRequestViaProxy(url, proxyStr);
            if (st == null)
            {
                return ConNotOk;
            }

            string doc = st.ReadToEnd();
            CQ dom = CsQuery.CQ.Create(doc);

            string title = dom["title"].Text();
            if (title.Contains("Did you spell it correctly?") || title.Contains("Oxford Learner's Dictionaries | Find the meanings"))
            {
                return SpelNotOk;
            }

            _wrd = GetElementText(dom, "h2", 0);
            if (_wrd.Equals("") || !title.Contains(_wrd))
            {
                return GenNotOk;
            }

            _oxfDocument = dom;

            return GenOk;
        }

        private string checkSohaContent(string word, string proxyStr)
        {
            string sohaUrl = "";
            if (word.Contains("tratu.soha.vn"))
            {
                sohaUrl = word;
            }
            else
            {
                word = word.Replace(" ", "+");
                sohaUrl = "http://tratu.soha.vn/index.php?search=" + word + "&dict=en_vn&btnSearch=&chuyennganh=&tenchuyennganh=";
            }

            StreamReader sohaSt = HttpGetRequestViaProxy(sohaUrl, proxyStr);
            if (sohaSt == null)
            {
                return ConNotOk;
            }

            string sohaDoc = sohaSt.ReadToEnd();
            CQ sohaDom = CsQuery.CQ.Create(sohaDoc);

            string sohaTitle = sohaDom["title"].Text();
            if (sohaTitle.Contains("Kết quả tìm"))
            {
                return SpelNotOk;
            }

            _sohaDocument = sohaDom;
            _sohaDocument = _sohaDocument.Select("h2 > span[class=mw-headline]").Before("<img src=\"minus_section.jpg\"> &nbsp;");
            _sohaDocument = _sohaDocument.Select("h3 > span[class=mw-headline]").After("&nbsp; <img src=\"minus_section.jpg\">");

            return GenOk;
        }

        private string GetPhonetic(CQ dom)
        {
            string phoneticBrE = GetElementText(dom, "span[class=phon]", 0);
            string phoneticNAmE = GetElementText(dom, "span[class=phon]", 1);

            if (phoneticBrE == "" && phoneticNAmE == "")
                return "There is no phonetic for this word!";

            string phonetic = phoneticBrE + phoneticNAmE;

            phonetic = phonetic.Replace("<span class=\"separator\">/</span>", "");
            phonetic = phonetic.Replace("<span class=\"bre\">BrE</span><span class=\"wrap\">/</span>", "BrE /");
            phonetic = phonetic.Replace("<span class=\"wrap\">/</span><span class=\"name\">NAmE</span><span class=\"wrap\">/</span>", "/  &nbsp; NAmE /");
            phonetic = "<span class=\"phon\">" + phonetic + "</span>";

            return phonetic;
        }

        private string GetExamples(CQ dom, string word)
        {
            IDomObject exampleElements = GetElementObject(dom, "span[class=x-g]", 0);
            if (exampleElements == null)
                return "There is no example for this word.";

            string examples = exampleElements.OuterHTML;

            for (int i = 1; i < 4; i++)
            {
                try
                {
                    examples += GetElementObject(dom, "span[class=x-g]", i).OuterHTML;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            examples = examples.Replace(word, "{{c1::" + word + "}}");
            examples = "<link type=\"text/css\" rel=\"stylesheet\" href=\"oxford.css\">" + examples;

            return examples;
        }

        private string GetPronunciation(CQ dom, string proxyStr, string selector)
        {
            string pro_link = GetElementAttributeValue(dom, selector, 0, "data-src-mp3");

            if (pro_link == "")
                return "";

            string pro_name = pro_link.Split('/')[pro_link.Split('/').Length - 1];

            Stream input = HttpGetRequestViaProxy(pro_link, proxyStr).BaseStream;
            FileStream output = File.OpenWrite(@".\AnkiFlashcards\sounds\" + pro_name);
            CopyStream(input, output);

            return "[sound:" + pro_name + "]";
        }

        private string GetImages(CQ dom, string proxyStr, string selector, string attr)
        {
            string img_link = GetElementAttributeValue(dom, selector, 0, attr);
            string word = GetElementText(dom, "h2", 0);

            if (img_link == "")
                return "<a href=\"https://www.google.com.vn/search?biw=1280&bih=661&tbm=isch&sa=1&q=" + word + "\" style=\"font-size: 15px; color: blue\">Images for this word</a>";

            string img_name = img_link.Split('/')[img_link.Split('/').Length - 1];
            if (attr.Equals("href"))
                img_name = "fullsize_" + img_name;

            Stream input = HttpGetRequestViaProxy(img_link, proxyStr).BaseStream;
            FileStream output = File.OpenWrite(@".\AnkiFlashcards\images\" + img_name);
            CopyStream(input, output);

            return "<img src=\"" + img_name + "\"/>";
        }

        private string GetOxfordContent(CQ dom)
        {
            IDomObject oxfContentElement = GetElementObject(dom, "#entryContent", 0);
            string oxfContent =
                "<html>" + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"interface.css\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"responsive.css\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"oxford.css\">" +
                "<div class=\"responsive_entry_center_wrap\">" + oxfContentElement.OuterHTML + "</div>" + "</html>";

            oxfContent = oxfContent.Replace("\t", "");
            oxfContent = oxfContent.Replace("\n", "");
            oxfContent = oxfContent.Replace("class=\"unbox\"", "class=\"unbox is-active\"");
            return oxfContent;
        }

        private string GetSohaContent(CQ dom)
        {
            IDomObject sohaContentElement = GetElementObject(dom, "#content", 0);
            string sohaContent =
                "<html>" + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"main_min.css\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"responsive.css\">" +
                "<div class=\"responsive_entry_center_wrap\">" + sohaContentElement.OuterHTML + "</div>" + "</html>";

            sohaContent = sohaContent.Replace("\t", "");
            sohaContent = sohaContent.Replace("\r", "");
            sohaContent = sohaContent.Replace("\n", "");

            sohaContent = HttpUtility.HtmlDecode(sohaContent);
            return sohaContent;
        }
        #endregion

        #region Basic Functions
        private string GetElementAttributeValue(CQ dom, string selector, int index, string attKey)
        {
            CQ elements = dom.Select(selector);

            try
            {
                return elements.Get(index).GetAttribute(attKey);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        }

        private string GetElementText(CQ dom, string selector, int index)
        {
            CQ elements = dom.Select(selector);

            try
            {
                //return elements.Get(index).OuterHTML;
                return elements.Get(index).InnerHTML;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        }

        private void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[8 * 1024];
            int len;
            while ((len = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                output.Write(buffer, 0, len);
            }
        }

        private IDomObject GetElementObject(CQ dom, string selector, int index)
        {
            CQ elements = dom.Select(selector);

            try
            {
                return elements.Get(index);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        private StreamReader HttpGetRequestViaProxy(string url, string proxyStr)
        {
            HttpWebRequest myWebRequest = (HttpWebRequest)WebRequest.Create(url);
            if (!string.IsNullOrEmpty(proxyStr))
            {
                WebProxy myproxy = new WebProxy(proxyStr, true);
                myproxy.BypassProxyOnLocal = true;
                myWebRequest.Proxy = myproxy;
            }

            myWebRequest.Method = "GET";
            HttpWebResponse response = null;
            try
            {
                response = (HttpWebResponse)myWebRequest.GetResponse();
            }
            catch (WebException e)
            {
                Console.WriteLine(e);
                return null;
            }

            StreamReader streamReader = new StreamReader(response.GetResponseStream());
            return streamReader;
        }
        #endregion
    }
}
