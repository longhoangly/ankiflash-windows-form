﻿using System;
using System.IO;
using System.Net;
using CsQuery;
using Mono.Web;

namespace FlascardsGenerator
{
    internal class FlashcardsGenerator
    {
        public CQ oxfDocument = "";
        public CQ sohaDocument = "";

        public string wrd = "";
        public string wordType = "";
        public string phonetic = "";
        public string example = "";
        public string pro_uk = "";
        public string pro_us = "";
        public string oxfContent = "";
        public string sohaContent = "";
        public string thumb = "";
        public string img = "";
        public char tag;
        public string ankiCard = "";
        public string copyRight = "";

        private string LangEng = "English";
        private string LangViet = "Vietnamese";
        private string LangEngViet = "English & Vietnamese";
        private string LangVietEng = "Vietnamese & English";

        private string SpelNotOk = "Spelling Failed";
        private string GenOk = "OK"; 
        public string ConNotOk = "Connection Failed"; 
        public string GenNotOk = "Generating Failed";

        public FlashcardsGenerator()
        {
            try
            {
                ClearDirectory("./sounds/");
                ClearDirectory("./images/");
            }
            catch (IOException e)
            {
                Console.WriteLine(e);
            }
            Directory.CreateDirectory("./sounds/");
            Directory.CreateDirectory("./images/");
        }

        public string GenerateFlashCards(string word, string proxyStr, string language)
        {
            Console.WriteLine("Generate Card for Word: " + word);
            if (language.Equals(LangEng))
            {
                if (checkOxfordContent(word, proxyStr).Equals(GenOk))
                {
                    oxfContent = GetOxfordContent(oxfDocument);
                }
                else if (checkOxfordContent(word, proxyStr).Equals(ConNotOk))
                {
                    return ConNotOk;
                }
                else
                {
                    return GenNotOk + "-" + word + "\r\n";
                }
            }
            else
            {
                if (checkOxfordContent(word, proxyStr).Equals(GenOk) && checkSohaContent(word, proxyStr).Equals(GenOk))
                {
                    oxfContent = GetOxfordContent(oxfDocument);
                    sohaContent = GetSohaContent(sohaDocument);
                    sohaContent = sohaContent.Replace("<div id=\"firstHeading\"> </div>", "<div id=\"firstHeading\">" + word + "</div>");
                }
                else if (checkOxfordContent(word, proxyStr).Equals(ConNotOk) && checkSohaContent(word, proxyStr).Equals(ConNotOk))
                {
                    return ConNotOk;
                }
                else
                {
                    return GenNotOk + "-" + word + "\r\n";
                }
            }

            wordType = "(" + GetElementText(oxfDocument, "span[class=pos]", 0) + ")";
            phonetic = GetPhonetic(oxfDocument);
            example = GetExamples(oxfDocument, wrd);
            pro_uk = GetPronunciation(oxfDocument, proxyStr, "div.pron-uk");
            pro_us = GetPronunciation(oxfDocument, proxyStr, "div.pron-us");
            thumb = GetImages(oxfDocument, proxyStr, "img.thumb", "src");
            img = GetImages(oxfDocument, proxyStr, "a[class=topic]", "href");
            tag = wrd[0];
            copyRight = "This flashcard's content is get from the Oxford Advanced Learner's & Soha Online Dictionaries.<br>Thanks Oxford & Soha Dictionaries! Thanks for using!";

            if (language.Equals(LangEng))
            {
                copyRight = "This flashcard's content is get from the Oxford Advanced Learner's Dictionary.<br>Thanks Oxford Dictionary! Thanks for using!";
                ankiCard = wrd + "\t" + wordType + "\t" + phonetic + "\t" + example + "\t" + pro_uk + "\t" + pro_us + "\t" + thumb + "\t" + img + "\t" + oxfContent + "\t" + copyRight + "\t" + tag + "\r\n";
            }
            else if (language.Equals(LangViet))
            {
                ankiCard = wrd + "\t" + wordType + "\t" + phonetic + "\t" + example + "\t" + pro_uk + "\t" + pro_us + "\t" + thumb + "\t" + img + "\t" + sohaContent + "\t" + copyRight + "\t" + tag + "\r\n";
            }
            else if (language.Equals(LangEngViet))
            {
                ankiCard = wrd + "\t" + wordType + "\t" + phonetic + "\t" + example + "\t" + pro_uk + "\t" + pro_us + "\t" + thumb + "\t" + img + "\t" + oxfContent + "\t" + sohaContent + "\t" + copyRight + "\t" + tag + "\r\n";
            }
            else
            {
                ankiCard = wrd + "\t" + wordType + "\t" + phonetic + "\t" + example + "\t" + pro_uk + "\t" + pro_us + "\t" + thumb + "\t" + img + "\t" + sohaContent + "\t" + oxfContent + "\t" + copyRight + "\t" + tag + "\r\n";
            }

            return ankiCard;
        }

        #region Functional Functions
        public string checkOxfordContent(string word, string proxyStr)
        {
            string url = "";
            if (word.Contains("www.oxfordlearnersdictionaries.com"))
            {
                url = word;
            }
            else
            {
                word = word.Replace(" ", "%20");
                url = "http://www.oxfordlearnersdictionaries.com/search/english/direct/?q=" + word;
            }

            StreamReader st = HttpGetRequestViaProxy(url, proxyStr);
            if (st == null)
            {
                return ConNotOk;
            }

            string doc = st.ReadToEnd();
            CQ dom = CsQuery.CQ.Create(doc);

            string title = dom["title"].Text();
            if (title.Contains("Did you spell it correctly?") || title.Contains("Oxford Learner's Dictionaries | Find the meanings"))
            {
                return SpelNotOk;
            }

            wrd = GetElementText(dom, "h2", 0);
            if (wrd.Equals("") || !title.Contains(wrd))
            {
                return GenNotOk;
            }

            oxfDocument = dom;

            return GenOk;
        }

        public string checkSohaContent(string word, string proxyStr)
        {
            string sohaUrl = "";
            if (word.Contains("tratu.soha.vn"))
            {
                sohaUrl = word;
            }
            else
            {
                word = word.Replace(" ", "+");
                sohaUrl = "http://tratu.soha.vn/index.php?search=" + word + "&dict=en_vn&btnSearch=&chuyennganh=&tenchuyennganh=";
            }

            StreamReader sohaSt = HttpGetRequestViaProxy(sohaUrl, proxyStr);
            if (sohaSt == null)
            {
                return ConNotOk;
            }

            string sohaDoc = sohaSt.ReadToEnd();
            CQ sohaDom = CsQuery.CQ.Create(sohaDoc);

            string sohaTitle = sohaDom["title"].Text();
            if (sohaTitle.Contains("Kết quả tìm"))
            {
                return SpelNotOk;
            }

            sohaDocument = sohaDom;
            sohaDocument = sohaDocument.Select("h2 > span[class=mw-headline]").Before("<img src=\"minus_section.jpg\"> &nbsp;");
            sohaDocument = sohaDocument.Select("h3 > span[class=mw-headline]").After("&nbsp; <img src=\"minus_section.jpg\">");

            return GenOk;
        }

        public string GetPhonetic(CQ dom)
        {
            string phoneticBrE = GetElementText(dom, "span[class=phon]", 0);
            string phoneticNAmE = GetElementText(dom, "span[class=phon]", 1);

            if (phoneticBrE == "" && phoneticNAmE == "")
                return "There is no phonetic for this word!";

            string phonetic = phoneticBrE + phoneticNAmE;

            phonetic = phonetic.Replace("<span class=\"separator\">/</span>", "");
            phonetic = phonetic.Replace("<span class=\"bre\">BrE</span><span class=\"wrap\">/</span>", "BrE /");
            phonetic = phonetic.Replace("<span class=\"wrap\">/</span><span class=\"name\">NAmE</span><span class=\"wrap\">/</span>", "/  &nbsp; NAmE /");
            phonetic = "<span class=\"phon\">" + phonetic + "</span>";

            return phonetic;
        }

        public string GetExamples(CQ dom, string word)
        {
            IDomObject exampleElements = GetElementObject(dom, "span[class=x-g]", 0);
            if (exampleElements == null)
                return "There is no example for this word.";

            string examples = exampleElements.OuterHTML;

            for (int i = 1; i < 4; i++)
            {
                try
                {
                    examples += GetElementObject(dom, "span[class=x-g]", i).OuterHTML;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            examples = examples.Replace(word, "{{c1::" + word + "}}");
            examples = "<link type=\"text/css\" rel=\"stylesheet\" href=\"oxford.css\">" + examples;

            return examples;
        }

        public string GetPronunciation(CQ dom, string proxyStr, string selector)
        {
            string pro_link = GetElementAttributeValue(dom, selector, 0, "data-src-mp3");

            if (pro_link == "")
                return "";

            string pro_name = pro_link.Split('/')[pro_link.Split('/').Length - 1];

            Stream input = HttpGetRequestViaProxy(pro_link, proxyStr).BaseStream;
            FileStream output = File.OpenWrite("./sounds/" + pro_name);
            CopyStream(input, output);

            return "[sound:" + pro_name + "]";
        }

        public string GetImages(CQ dom, string proxyStr, string selector, string attr)
        {
            string img_link = GetElementAttributeValue(dom, selector, 0, attr);
            string word = GetElementText(dom, "h2", 0);

            if (img_link == "")
                return "<a href=\"https://www.google.com.vn/search?biw=1280&bih=661&tbm=isch&sa=1&q=" + word + "\" style=\"font-size: 15px; color: blue\">Images for this word</a>";

            string img_name = img_link.Split('/')[img_link.Split('/').Length - 1];
            if (attr.Equals("href"))
                img_name = "fullsize_" + img_name;

            Stream input = HttpGetRequestViaProxy(img_link, proxyStr).BaseStream;
            FileStream output = File.OpenWrite("./images/" + img_name);
            CopyStream(input, output);

            return "<img src=\"" + img_name + "\"/>";
        }

        public string GetOxfordContent(CQ dom)
        {
            IDomObject oxfContentElement = GetElementObject(dom, "#entryContent", 0);
            string oxfContent =
                "<html>" + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"interface.css\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"responsive.css\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"oxford.css\">" +
                "<div class=\"responsive_entry_center_wrap\">" + oxfContentElement.OuterHTML + "</div>" + "</html>";

            oxfContent = oxfContent.Replace("\t", "");
            oxfContent = oxfContent.Replace("\n", "");
            oxfContent = oxfContent.Replace("class=\"unbox\"", "class=\"unbox is-active\"");
            return oxfContent;
        }

        public string GetSohaContent(CQ dom)
        {
            IDomObject sohaContentElement = GetElementObject(dom, "#content", 0);
            string sohaContent =
                "<html>" + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"main_min.css\">" +
                "<link type=\"text/css\" rel=\"stylesheet\" href=\"responsive.css\">" +
                "<div class=\"responsive_entry_center_wrap\">" + sohaContentElement.OuterHTML + "</div>" + "</html>";

            sohaContent = sohaContent.Replace("\t", "");
            sohaContent = sohaContent.Replace("\r", "");
            sohaContent = sohaContent.Replace("\n", "");

            sohaContent = HttpUtility.HtmlDecode(sohaContent);
            return sohaContent;
        }
        #endregion

        #region Basic Functions
        public string GetElementAttributeValue(CQ dom, string selector, int index, string attKey)
        {
            CQ elements = dom.Select(selector);

            try
            {
                return elements.Get(index).GetAttribute(attKey);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        }

        public string GetElementText(CQ dom, string selector, int index)
        {
            CQ elements = dom.Select(selector);

            try
            {
                //return elements.Get(index).OuterHTML;
                return elements.Get(index).InnerHTML;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
            }
        }

        public IDomObject GetElementObject(CQ dom, string selector, int index)
        {
            CQ elements = dom.Select(selector);

            try
            {
                return elements.Get(index);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[8 * 1024];
            int len;
            while ((len = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                output.Write(buffer, 0, len);
            }
        }

        public StreamReader HttpGetRequestViaProxy(string url, string proxyStr)
        {
            HttpWebRequest myWebRequest = (HttpWebRequest)WebRequest.Create(url);
            if (!string.IsNullOrEmpty(proxyStr))
            {
                WebProxy myproxy = new WebProxy(proxyStr, true);
                myproxy.BypassProxyOnLocal = true;
                myWebRequest.Proxy = myproxy;
            }

            myWebRequest.Method = "GET";
            HttpWebResponse response = null;
            try
            {
                response = (HttpWebResponse)myWebRequest.GetResponse();
            }
            catch (WebException e)
            {
                Console.WriteLine(e);
                return null;
            }

            StreamReader streamReader = new StreamReader(response.GetResponseStream());
            return streamReader;
        }

        public static void ClearDirectory(string dirPath)
        {
            DirectoryInfo dir = new DirectoryInfo(dirPath);

            foreach (FileInfo fi in dir.GetFiles())
            {
                fi.Delete();
            }

            foreach (DirectoryInfo di in dir.GetDirectories())
            {
                ClearDirectory(di.FullName);
                di.Delete();
            }

            Directory.Delete(dirPath, false);
        }
        #endregion
    }
}
